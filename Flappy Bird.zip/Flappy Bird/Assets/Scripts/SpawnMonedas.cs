using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnMonedas : MonoBehaviour
{
    [SerializeField] private float _tiempoMaximo = 4.5f; // Intervalo m�ximo entre spawns
    [SerializeField] private float _rangoAltura = 0.45f; // Rango aleatorio en la altura de las monedas
    [SerializeField] private GameObject _monedaPrefab;   // Prefab de la moneda a instanciar

    private float _temporizador; // Temporizador para controlar el spawn de monedas

    // Se ejecuta al inicio
    private void Start()
    {
        GenerarMoneda(); // Genera la primera moneda al iniciar
    }

    // Se ejecuta en cada frame
    private void Update()
    {
        if (_temporizador >= _tiempoMaximo)
        {
            GenerarMoneda(); // Genera una nueva moneda cuando se alcanza el tiempo m�ximo
            _temporizador = 0; // Reinicia el temporizador
        }

        _temporizador += Time.deltaTime; // Incrementa el temporizador con el tiempo transcurrido
    }

    // Genera una nueva moneda
    private void GenerarMoneda()
    {
        Vector3 posicionSpawn = transform.position + new Vector3(0, Random.Range(-_rangoAltura, _rangoAltura));
        GameObject moneda = Instantiate(_monedaPrefab, posicionSpawn, Quaternion.identity);

        Destroy(moneda, 10f); // Destruye la moneda despu�s de 10 segundos
    }
}

