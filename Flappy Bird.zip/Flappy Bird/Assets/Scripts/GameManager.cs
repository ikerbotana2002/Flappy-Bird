using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GestorJuego : MonoBehaviour
{
    public static GestorJuego instancia; // Instancia �nica de la clase

    [SerializeField] private GameObject _pantallaGameOver; // Canvas para mostrar el Game Over

    private void Awake()
    {
        // Configura el patr�n singleton para asegurar que solo haya una instancia
        if (instancia == null)
        {
            instancia = this;
        }

        // Restablece el tiempo del juego a su velocidad normal
        Time.timeScale = 1f;
    }

    // M�todo para gestionar el fin del juego
    public void FinDelJuego()
    {
        // Muestra el Canvas de Game Over
        _pantallaGameOver.SetActive(true);

        // Pausa el juego deteniendo el tiempo
        Time.timeScale = 0f;
    }

    // M�todo para reiniciar el juego
    public void ReiniciarJuego()
    {
        // Recarga la escena actual
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}

