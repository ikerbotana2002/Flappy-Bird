using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CicloSuelo : MonoBehaviour
{
    [SerializeField] private float _velocidad = 1f; // Velocidad del movimiento del suelo
    [SerializeField] private float _ancho = 6f;    // Ancho m�ximo antes de reiniciar el ciclo

    private SpriteRenderer _renderizadorSprite; // Componente SpriteRenderer del objeto
    private Vector2 _tamanoInicial;             // Tama�o inicial del sprite

    private void Start()
    {
        _renderizadorSprite = GetComponent<SpriteRenderer>();
        _tamanoInicial = new Vector2(_renderizadorSprite.size.x, _renderizadorSprite.size.y);
    }

    private void Update()
    {
        // Incrementa el tama�o horizontal del sprite seg�n la velocidad
        _renderizadorSprite.size = new Vector2(_renderizadorSprite.size.x + _velocidad * Time.deltaTime, _renderizadorSprite.size.y);

        // Reinicia el tama�o cuando supera el ancho especificado
        if (_renderizadorSprite.size.x >= _ancho)
        {
            _renderizadorSprite.size = _tamanoInicial;
        }
    }
}
