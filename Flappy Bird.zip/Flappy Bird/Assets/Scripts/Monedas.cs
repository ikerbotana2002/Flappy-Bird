using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monedas : MonoBehaviour
{
    [SerializeField] private float _velocidad = 0.65f;

    // Update is called once per frame
    private void Update()
    {
        // Mueve la moneda hacia la izquierda
        transform.position += Vector3.left * _velocidad * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Verifica si el objeto que colisiona es el jugador
        if (other.CompareTag("Player"))
        {
            // Destruye la moneda para que desaparezca
            Destroy(gameObject);
        }
    }
}
