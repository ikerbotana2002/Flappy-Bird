using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class ComportamientoNuevo : MonoBehaviour
{
    [SerializeField] private float _velocidad = 1.5f; // Velocidad del salto hacia arriba
    [SerializeField] private float _velocidadRotacion = 10f; // Velocidad de rotaci�n del objeto

    private Rigidbody2D _rigidoCuerpo; // Componente Rigidbody2D del objeto

    [SerializeField] private AudioClip sonidoClick;  // Sonido para reproducir al hacer clic
    [SerializeField] private AudioClip sonidoChoque; // Sonido para reproducir al colisionar
    private AudioSource fuenteAudio;                // Componente de audio para reproducir sonidos

    // Este m�todo se ejecuta al inicio del juego
    void Start()
    {
        _rigidoCuerpo = GetComponent<Rigidbody2D>();

        fuenteAudio = GetComponent<AudioSource>();
        if (fuenteAudio == null)
        {
            fuenteAudio = gameObject.AddComponent<AudioSource>();
        }
    }

    // Este m�todo se ejecuta en cada frame
    private void Update()
    {
        // Verifica si se presion� el bot�n izquierdo del mouse
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            // Aplica una velocidad hacia arriba
            _rigidoCuerpo.velocity = Vector2.up * _velocidad;

            // Reproduce el sonido del clic si existe
            if (sonidoClick != null && fuenteAudio != null)
            {
                fuenteAudio.PlayOneShot(sonidoClick);
            }
        }
    }

    private void FixedUpdate()
    {
        // Ajusta la rotaci�n del objeto seg�n su velocidad vertical
        transform.rotation = Quaternion.Euler(0, 0, _rigidoCuerpo.velocity.y * _velocidadRotacion);
    }

    // Este m�todo se ejecuta al colisionar con otro objeto
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Reproduce el sonido del choque si existe
        if (sonidoChoque != null && fuenteAudio != null)
        {
            fuenteAudio.PlayOneShot(sonidoChoque);
        }

        GestorJuego.instancia.FinDelJuego();
    }
}

