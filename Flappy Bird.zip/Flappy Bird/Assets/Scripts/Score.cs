using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Puntaje : MonoBehaviour
{
    public static Puntaje instancia; // Instancia �nica para acceder al puntaje global

    [SerializeField] private TextMeshProUGUI _textoPuntajeActual; // Texto para mostrar el puntaje actual
    [SerializeField] private TextMeshProUGUI _textoPuntajeMaximo; // Texto para mostrar el puntaje m�ximo

    private int _puntaje; // Almacena el puntaje actual del jugador

    // Se ejecuta al inicializar el objeto
    private void Awake()
    {
        // Configura la instancia �nica
        if (instancia == null)
        {
            instancia = this;
        }
    }

    // Se ejecuta al iniciar la escena
    private void Start()
    {
        _textoPuntajeActual.text = _puntaje.ToString(); // Muestra el puntaje actual
        _textoPuntajeMaximo.text = PlayerPrefs.GetInt("PuntajeMaximo", 0).ToString(); // Obtiene el puntaje m�ximo almacenado
        ActualizarPuntajeMaximo(); // Actualiza el puntaje m�ximo si es necesario
    }

    // M�todo para verificar y actualizar el puntaje m�ximo
    private void ActualizarPuntajeMaximo()
    {
        if (_puntaje > PlayerPrefs.GetInt("PuntajeMaximo")) // Si el puntaje actual supera el m�ximo almacenado
        {
            PlayerPrefs.SetInt("PuntajeMaximo", _puntaje); // Guarda el nuevo puntaje m�ximo
            _textoPuntajeMaximo.text = _puntaje.ToString(); // Actualiza el texto del puntaje m�ximo
        }
    }

    // M�todo p�blico para incrementar el puntaje actual
    public void ActualizarPuntaje()
    {
        _puntaje++; // Incrementa el puntaje en 1
        _textoPuntajeActual.text = _puntaje.ToString(); // Actualiza el texto del puntaje actual
        ActualizarPuntajeMaximo(); // Verifica si debe actualizarse el puntaje m�ximo
    }
}
