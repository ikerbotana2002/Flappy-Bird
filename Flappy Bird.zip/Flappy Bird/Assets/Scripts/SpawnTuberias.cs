using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerarTuberias : MonoBehaviour
{
    [SerializeField] private float _tiempoMaximo = 1.5f; // Tiempo m�ximo entre spawns
    [SerializeField] private float _rangoAltura = 0.45f; // Rango de altura para las tuber�as
    [SerializeField] private GameObject _tuberiaPrefab;  // Prefab de la tuber�a

    private float _temporizador; // Temporizador para el intervalo de spawn

    private void Start()
    {
        GenerarTuberia(); // Genera una tuber�a al inicio
    }

    private void Update()
    {
        if (_temporizador >= _tiempoMaximo)
        {
            GenerarTuberia();
            _temporizador = 0; // Reinicia el temporizador
        }

        _temporizador += Time.deltaTime; // Incrementa el temporizador cada frame
    }

    private void GenerarTuberia()
    {
        // Calcula la posici�n aleatoria para la tuber�a
        Vector3 posicionSpawn = transform.position + new Vector3(0, Random.Range(-_rangoAltura, _rangoAltura));

        // Crea una tuber�a en la posici�n calculada
        GameObject tuberia = Instantiate(_tuberiaPrefab, posicionSpawn, Quaternion.identity);

        // Destruye la tuber�a despu�s de 10 segundos
        Destroy(tuberia, 10f);
    }
}
